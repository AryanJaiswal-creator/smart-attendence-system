import cv2
from datetime import datetime, timedelta
from config import Config
from services.motion_service import MotionDetector
from services.countdown_service import countdown_service
from services.system_state import system_state
from services.qr_service import qr_service
from services.report_service import report_service
import os

print("Process ID:", os.getpid())


class RealtimeEngine:

    def __init__(self):

        # Open Camera
        self.camera = cv2.VideoCapture(0, cv2.CAP_DSHOW)
        self.camera.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
        self.camera.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)

        # Motion Detector
        self.motion_detector = MotionDetector()
        self.frame = None
        self._last_lunch_date = None
        self._last_report_date = None

    def _within_operating_hours(self, now):
        if not Config.SYSTEM_START_TIME or not Config.SYSTEM_STOP_TIME:
            return True
        current = now.strftime("%H:%M")
        return Config.SYSTEM_START_TIME <= current < Config.SYSTEM_STOP_TIME

    def _update_lunch_mode(self, now):
        start = datetime.strptime(Config.LUNCH_START, "%H:%M").time()
        lunch_start = datetime.combine(now.date(), start)
        lunch_end = lunch_start + timedelta(minutes=Config.LUNCH_DURATION)
        system_state.break_mode = lunch_start <= now < lunch_end
        if system_state.break_mode:
            countdown_service.stop()

    def _send_scheduled_report(self, now):
        if (Config.DAILY_REPORT_TIME and
                now.strftime("%H:%M") >= Config.DAILY_REPORT_TIME and
                self._last_report_date != now.date()):
            report_service.send_daily_report(now.date())
            self._last_report_date = now.date()

    # ==========================================
    # Start Engine
    # ==========================================
    def run(self):

        print("======================================")
        print("RealtimeEngine.run() called")
        print("======================================")

        if not self.camera.isOpened():
            print("❌ Camera could not be opened.")
            return

        print("✅ Camera opened successfully")

        system_state.camera_online = True
        system_state.motion_detected = False
        system_state.scanner_enabled = False
        system_state.siren_on = False

        # =====================================
        # FPS Variables
        # =====================================

        fps = 0
        previous_time = cv2.getTickCount()

        while True:

            

            success, frame = self.camera.read()
            now = datetime.now()
            system_state.system_active = self._within_operating_hours(now)
            self._update_lunch_mode(now)
            self._send_scheduled_report(now)
            # =====================================
            # Calculate FPS
            # =====================================

            current_time_tick = cv2.getTickCount()

            time_elapsed = (
                current_time_tick - previous_time
            ) / cv2.getTickFrequency()

            previous_time = current_time_tick

            if time_elapsed > 0:

                fps = int(1 / time_elapsed)

            

            if not success:
                print("❌ Failed to read frame")
                break
            H, W = frame.shape[:2]
            print(f"Width = {W}, Height = {H}")

            # =====================================
            # Draw Detection Zone
            # =====================================
            zone_color = (
                (0,255,0)
                if system_state.motion_detected
                else (0,0,255)
            )

            # =====================================
            # Motion Detection
            # =====================================
            motion = self.motion_detector.detect_motion(frame)
            system_state.motion_detected = motion

            if motion and system_state.system_active and not system_state.break_mode:

                cv2.putText(
                    frame,
                    "MOTION DETECTED",
                    (20,40),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.8,
                    (0,255,0),
                    2
                )
                if not system_state.countdown_running:
                    countdown_service.start()


            # =====================================
            # QR Scanner
            # =====================================
            if system_state.scanner_enabled:

                qr_service.scan(frame)

            # =====================================
            # Left Status Panel Background
            # =====================================

            cv2.rectangle(
                frame,
                (20, 100),
                (340, 360),
                (40, 40, 40),
                -1
            )

            cv2.rectangle(
                frame,
                (20, 100),
                (340, 360),
                (0, 180, 255),
                2
            )

            cv2.putText(
                frame,
                "SYSTEM STATUS",
                (40, 135),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.75,
                (255,255,255),
                2
            )

            # =====================================
            # System Title
            # =====================================
        
            header_h = 80
            cv2.rectangle(
                frame,
                (0, 0),
                (W,header_h),
                (25,25,25),
                -1
            )
            # Bottom Border
            cv2.line(
                frame,
                (0, header_h),
                (W, header_h),
                (0, 180, 255),
                2
            )

            cv2.putText(
                frame,
                "SMART CLASSROOM ENTRY MONITORING SYSTEM",
                (20,45),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (255, 255, 255),
                2
            )

            # =====================================
# Date & Time
# =====================================

            current_time = datetime.now().strftime("%d-%m-%Y  %I:%M:%S %p")

            cv2.putText(
                frame,
                current_time,
                (W - 320, 70),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6,
                (0, 255, 255),
                2
)
            # =====================================
            # Camera Status
            # =====================================
            camera_color = (
                (0,255,0)
                if system_state.camera_online
                else (0,0,255)
            )

            cv2.circle(
                frame,
                (50,180),
                7,
                camera_color,
                -1
            )

            cv2.putText(
                frame,
                "Camera",
                (70,186),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6,
                (255,255,255),
                2
            )

            # =====================================
            # Motion Status
            # =====================================
            motion_color = (
                (0,255,0)
                if system_state.motion_detected
                else (0,0,255)
            )

            cv2.circle(
                frame,
                (50,215),
                7,
                motion_color,
                -1
            )

            cv2.putText(
                frame,
                "Motion",
                (70,231),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6,
                (255,255,255),
                2
            )

            # =====================================
            # Countdown
            # =====================================
            if system_state.countdown_running:

                cv2.rectangle(
                    frame,
                    (15,105),
                    (260,145),
                    (0,0,0),
                    -1
                )

                cv2.putText(
                    frame,
                    f"Countdown : {system_state.countdown_seconds}",
                    (20,135),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.8,
                    (0,255,255),
                    2
            )


            # =====================================
            # Scanner Status
            # =====================================
            scanner_color = (
                (0,255,0)
                if system_state.scanner_enabled
                else (0,0,255)
            )

            cv2.circle(
                frame,
                (50,270),
                7,
                scanner_color,
                -1
            )

            cv2.putText(
                frame,
                "Scanner",
                (70,276),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6,
                (255,255,255),
                2
            )

            # =====================================
            # Siren Status
            # =====================================
            siren_color = (
                (0,0,255)
                if system_state.siren_on
                else (0,255,0)
            )

            cv2.circle(
                frame,
                (50,315),
                7,
                siren_color,
                -1
            )

            cv2.putText(
                frame,
                "Siren",
                (70,321),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6,
                (255,255,255),
                2
            )

            # =====================================
            # Last Student
            # =====================================
            if system_state.last_student:

                cv2.putText(
                    frame,
                    f"Last Scan : {system_state.last_student}",
                    (20, 290),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.7,
                    (255, 255, 255),
                    2
                )
            # =====================================
# FPS Display
# =====================================

            cv2.putText(
            frame,
            f"FPS : {fps}",
            (20, frame.shape[0] - 20),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.65,
            (0,255,255),
            2
        )
            self.frame = frame.copy()

            # =====================================
            # Camera Window
            # =====================================
           # cv2.imshow(
           #     "Smart Classroom Entry Monitoring System",
            #    frame
            #)

            #key = cv2.waitKey(1) & 0xFF

            #if key == 27:
            #    break

        # =====================================
        # Cleanup
        # =====================================
        self.camera.release()

        #cv2.destroyAllWindows()

        system_state.camera_online = False

        print("Realtime Engine Stopped")


# ==========================================
# Create Engine Object
# ==========================================
realtime_engine = RealtimeEngine()
