import threading
import time

from config import Config
from services.alert_service import alert_service
from services.system_state import system_state


class CountdownService:

    def __init__(self):

        self.thread = None

    # ==========================================
    # Start Countdown
    # ==========================================
    def start(self):

        # Motion opens the QR reader immediately, just as it did in the
        # legacy desktop system.  A single timer then covers the whole scan
        # window; there is no extra pre-countdown.
        if system_state.processing:
            return

        system_state.processing = True

        self.thread = threading.Thread(

            target=self.run,

            daemon=True

        )

        self.thread.start()

    # ==========================================
    # Countdown Logic
    # ==========================================
    def run(self):

        system_state.countdown_running = True
        system_state.countdown_seconds = Config.QR_SCAN_WINDOW_SECONDS
        system_state.scanner_enabled = True

        print("⏳ Countdown Started")

        while system_state.countdown_seconds > 0:

            print(
                f"Countdown : {system_state.countdown_seconds}"
            )

            time.sleep(1)

            system_state.countdown_seconds -= 1

            # QR already scanned
            if not system_state.processing:

                print("✅ Countdown Cancelled")

                return

        # The student did not scan within the window.
        system_state.countdown_running = False
        # Keep scanning after the timeout.  The siren is an alert, not a
        # scanner lockout: a valid QR scan must still be able to clear it.
        system_state.scanner_enabled = True
        alert_service.start_siren()

        print("🚨 SIREN STARTED")


    # ==========================================
    # Stop Countdown
    # ==========================================
    def stop(self):

        system_state.processing = False

        system_state.countdown_running = False

        system_state.countdown_seconds = 5

        system_state.scanner_enabled = False

        system_state.siren_on = False
        alert_service.stop_siren()

        print("✅ Countdown Reset")


countdown_service = CountdownService()
